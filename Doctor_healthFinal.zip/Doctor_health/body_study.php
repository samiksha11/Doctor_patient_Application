<?php
include("config.php");
if($_SESSION['email'] == '')
{
	//header("Location:index.php");
}

error_reporting(0);
$rs_history_all= getAllRecordFromTableWithJoin('patient_history',array('`disease`'=>'`disease`.`disease_id`=`patient_history`.`disease_id`'),array('`patient_history`.`patient_id`'=>$_SESSION['Patient_id']),'`patient_history`.*,`disease`.`disease_name`');

//var_dump($rs_history_all);

$rs_disease_detail = getAllDataFromTable('disease',array('disease`.`disease_id'=>$disease_id),'', '*');
$disease_detail = $rs_disease_detail[0];

$rs_medicine_detail = getAllDataFromTable('medicine',array('medicine`.`medicine_id'=>$medicine_name),'','medicine_name'); 
$get_medicine_detail = $rs_medicine_detail[0];

if(isset($_POST['submit']) && $_POST['submit'] == 'Save History'){ 
	 //var_dump($_POST); die;
       patient_history();
}
?>
<?php include_once ('Includes/header.php'); ?>
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<div id="column-middle">
<div id="p-story-box" class="white-background" style="display:block; height:1040px;width:950px">
    <div id="p-title-box" class="title-box-background-orange title-medium" >Study</div>
    <table cellspacing="1" cellpadding="6" width="950" border="0">
    <thead>
        <tr bgcolor="#e1f2e0" valign="middle">
            <th id="bpc" align="center">Blood Pressure<br>Category</th>
            <th id="sys" valign="middle" align="center">Systolic<br>mm Hg
            
            <th id="dia" valign="middle" align="center">Diastolic<br>mm Hg</th>
        </tr></thead>
    <tbody>
        <tr valign="middle">
            <th id="norm" bgcolor="green" headers="bpc" align="center">Normal
            </th>
            <td bgcolor="green" valign="middle" headers="norm sys" align="center">< <strong>120</strong></td>
            <td bgcolor="green" valign="middle" headers="norm dia" align="center">< <strong>80</strong></td>
        </tr><tr bgcolor="yellow" valign="middle"><th id="pre" bgcolor="yellow" headers="bpc" align="center">Hypertension</th>
            <td bgcolor="yellow" valign="middle" headers="pre sys" align="center"><strong> < </strong><strong>120</strong><strong> < </strong><strong>139</strong></td>
            </td><td bgcolor="yellow" valign="middle" headers="pre dia" align="center"><strong> < </strong><strong>80</strong><strong> < </strong><strong>89</strong></td>
        </tr><tr valign="middle"><th id="hbp1" bgcolor="orange" headers="bpc" align="center">Hypertension 
                Stage 1</th>
            <td bgcolor="orange" valign="middle" headers="hbp1 sys" align="center"> <strong> < </strong><strong>140</strong> > <strong>159</strong></td>
            <td bgcolor="orange" valign="middle" headers="hbp1 dia" align="center"> <strong> < </strong><strong>90</strong><strong> < </strong><strong>99</strong></td>
        </tr><tr bgcolor="orangered" valign="middle"><th id="hbp2" bgcolor="orangered" headers="bpc" align="center">Hypertension Stage 2</th>
            <td bgcolor="orangered" valign="middle" headers="hbp2 sys" align="center"><strong>160</strong> or ></td>
           
            <td bgcolor="orangered" valign="middle" headers="hbp2 dia" align="center"><strong>100</strong> or ></td></tr>
        <tr valign="middle"><th id="htc" bgcolor="red" headers="bpc" align="center"><span style="color: #fff">Emergency</span></th>
            <td bgcolor="red" valign="middle" headers="htc sys" align="center"><span style="color: #fff">> <strong>180</strong></span></td>
            
            <td bgcolor="red" valign="middle" headers="htc dia" align="center"><span style="color: #fff">> <strong>110</strong></span></td></tr>
    </tbody>
    </table>
</div>

</body>
</html>