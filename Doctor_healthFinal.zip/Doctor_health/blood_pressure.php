<?php
include("config.php");
if($_SESSION['email'] == '')
{
	//header("Location:index.php");
}

error_reporting(0);
//$rs_patient_bp= getAllRecordFromTableWithJoin('patient_history',array('`disease`'=>'`disease`.`disease_id`=`patient_history`.`disease_id`'),array('`patient_history`.`patient_id`'=>$_SESSION['Patient_id']),'`patient_history`.*,`disease`.`disease_name`');

//var_dump($rs_history_all);

$rs_patient_bp = getAllDataFromTable('patient_bp',array('Patient_id'=>$_REQUEST['pid']),'', '*');
$bp_detail = $rs_patient_bp[0];



if(isset($_POST['submit']) && $_POST['submit'] == 'Save BP'){ 
	 //var_dump($_POST); die;
       patient_bp();
      
}
?>
<?php include_once ('Includes/header.php'); ?>
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<div id="column-middle">
<div id="p-story-box" class="white-background" style="min-height: 996px">
    <div id="p-title-box" class="title-box-background-orange title-medium">My Blood Pressure </div>
        <table cellpadding="10"> 
       
        <td style="border-bottom:2px solid #CCC;width:10%">Sr No</td>
        <td style="border-bottom:2px solid #CCC;width:10%">Date</td>
        <td style="border-bottom:2px solid #CCC;width:10%">Time</td>
        <td style="border-bottom:2px solid #CCC;width:10%">Systolic</td>
        <td style="border-bottom:2px solid #CCC;width:10%">Diastolic</td>
        <td style="border-bottom:2px solid #CCC;width:10%">Status</td>
       
      <?php $i = 1; foreach($rs_patient_bp as $bpList){?>
     <tr style="border-bottom:1px solid #CCC;">
     <td><?php echo $i;?></td>
          <td><?php echo $bpList['bp_date'];?></td>
          <td><?php echo $bpList['bp_time'];?></td>
          <td><?php echo $bpList['systolic'];?></td>
          <td><?php echo $bpList['diastolic'];?></td>
          <?php if ($bpList['systolic']<120  && $bpList['diastolic']<80)
          {?><td><div style="height:20px; background:green;"><strong>N</strong></div></td><?php
          }?>
          <?php if (($bpList['systolic']>120&&$bpList['systolic']<139)  &&($bpList['diastolic']>80&&$bpList['diastolic']<89))
          {?><td><div style="height:20px; background:yellow;"><strong>H</strong></div></td><?php
          }?>
          
          <?php if (($bpList['systolic']>140&&$bpList['systolic']<159)  &&($bpList['diastolic']>90&&$bpList['diastolic']<99))
          {?><td><div style="height:20px; background:orange;"><strong>SG1</strong></div></td><?php
          }?>
          <?php if (($bpList['systolic']>160&&$bpList['systolic']<180)  &&($bpList['diastolic']>100&&$bpList['diastolic']<110))
          {?><td><div style="height:20px; background:orangered;"><strong>SG2</strong></div></td><?php
          }?>
          <?php if ($bpList['systolic']>180  && $bpList['diastolic']>110)
          {?><td><div style="height:20px; background:red;"><strong>DOC</strong></div></td><?php
          }?>
          <td><?php echo $historyList['alleregy'];?></td>
        </tr>

     
      
           <?php $i++; }?> </table>
              </fieldset>
  </div>
  </div>
  <div id="column-middle">
  <div id="p-story-box" class="white-background" style="min-height:996px">
    <div id="p-title-box" class="title-box-background-orange title-medium"> Blood Pressure </div>
    <form method="POST" action="" enctype="multipart/form-data" >
      <table cellpadding="10">
        <tr>
          <td><strong>Systolic</strong> </td>
          <td><input type name="systolic" id="catname" required>
              <th cellspacing="0">mm Hg</th>
              </td>
        </tr>
        <tr>
          <td  style="width:300px;"> <strong>Diastolic</strong> </td>
          <td><input type="text" name="diastolic" required>
          <th><strong>mm Hg</strong></th></td>
        </tr>
        <tr>
          <td><strong>Time</strong> </td>
          <td><select name="time">
            <option value="Morning">Morning</option>
            <option value="Evening">Evening</option>
              </select></td></tr>
       <!-- <tr id="Date">
          <td><strong>Date</strong></td>
          <td><input type="datepicker" id="datepicker" name="date" size="20" ></td>
        </tr >-->
        
         <tr id="Date">
            <td style="width:200px;color:#1E5A9d;font-weight:bold;">DATE</td>
            <td><input type="date" id="datepicker1" name="datepicker"  /></td>
              </td>
          </tr>
       <!-- <tr>
          <td  style="width:300px;"> <strong>Device Certificate</strong> </td>
          <td><input type="file" name="fileToUpload" id="fileToUpload"></td>
        </tr>-->
        
        
        <?php $patientID = substr($_REQUEST['pid']);?>
        <tr>
          <td>
          <input type="hidden" name="patientID" value="<?php echo $patientID;?>" />
          <input id="button" type="submit" name="submit" value="Save BP" /></td>
          </tr>
      </table>
    </form>
    </fieldset>
  </div>
</div>

</body>
</html>