<?php

include("config.php");
if($_SESSION['email'] == '')
{
	//header("Location:index.php");
}

error_reporting(0);
if(isset($_POST['submit']) && $_POST['submit'] == 'REPLY'){ 
	// var_dump($_POST); die;
   //$date = DATE_FORMAT('".$datetime."',%Y-%m-%d);
    $new_date_format = date("Y-m-d H:i:s", strtotime($datetime));
    $patientID = substr($_REQUEST['pid'], 10, -10);
    $appointmentID = substr($_REQUEST['aid'], 10, -10);
    $sql = "update `health_care_db`.`appointment`set 
		appointment.schedule_time ='".$new_date_format."'
     		              where Patient_id = '".$patientID."' and appointment_id='".$appointmentID."' ";
			//echo $sql; die;	
	$qry = mysql_query($sql);
         
        fix_Appointment();
        $sql2= "update `health_care_db`.`appointment`set 
		appointment.pending_status ='1'
     		              where Patient_id = '".$patientID."' and appointment_id='".$appointmentID."' ";
			//echo $sql2; die;	
	$qry2 = mysql_query($sql2);
        
        
}
?>
<?php include_once ('Includes/header.php'); ?>
<div id="column-middle">
  <div id="p-story-box" class="white-background">
    <div id="p-title-box" class="title-box-background-orange title-medium">Appointment Reply </div>
    <form method="POST" action="" enctype="multipart/form-data" >
      <table cellpadding="10">
        <tr>
          <td><strong>Message</strong> </td>
          <td><textarea id="tooltip-1" title="please provide your reply for appointment"name="message"></textarea></td>
            </td>
        </tr>
        <tr>
        
          <td><b>Appointment Date </b></td>
           <td><input type="text" data-field="datetime" readonly class="input" name="datetime" id="datetime">
            <div id="DateTimePicker"></div></td>
        </tr>
        <tr>
        
          <td><b> Upload NDA </b></td>
          <td><input type="file" name="nda_form" id="fileToUpload"></td>
        </tr>
        <?php $patientID = substr($_REQUEST['pid'], 10, -10);
                $appointmentID = substr($_REQUEST['aid'], 10, -10);?>
        <tr>
          <td>
          <input type="hidden" name="patientID" value="<?php echo $patientID;?>" />
          <input type="hidden" name="appointID" value="<?php echo $appointmentID;?>" />
          <input id="button1" type="submit" name="submit" value="REPLY" /></td>
          </tr>
      </table>
    </form>
    </fieldset>
  </div>
</div>
<script>
$(document).ready(function(){
   $("#DateTimePicker").DateTimePicker();
   
});
 
</script>

</body>
</html>