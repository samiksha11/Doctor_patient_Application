<?php
include("config.php");

if($_SESSION['email'] !== '')
{
	session_regenerate_id(true);
//header("Location:index.php");
}
echo$Doctors_id = $_REQUEST['did'];
error_reporting(0);
if(isset($_POST['submit']) && $_POST['submit'] == 'Add Patient')
{
   //var_dump($_POST);
   //die();
    NewPaitents();
    header("Location:d_patient_list.php");
}
  
?>
<?php
     include_once ('Includes/header.php');
     ?>
<div id="column-right" style="display:block; height:1040px;width:950px" >
  



<div id="column-Add-patient" style="display: block">
<div id="Patient-story-box" class="patient-background">
  <div id="title-box" class="title-box-background-orange title-medium">New patient 
  <img src="Images/back.png" width="90" height="75"  onclick="goBack()" style="float:right"/>
      <script>
function goBack() {
    window.history.back();
}
</script>
  </div>
  <div id="Doctor-Sign-Up">
    <form  id="register-form" novalidate="novalidate" method="POST" action="" onsubmit="vsubmit();">
      <fieldset style="width:50%">
        <table border="0" id="regis_form" style="display: block;" cellpadding="10">
          <tr>
            <td>Name</td>
            <td><input type="text" name="fullname"></td>
          </tr>
          <tr >
            <td>Email</td>
            <td><input type="email" name="email1" id ="email1" class ="required email"></td>
          </tr>
          <tr>
            <td>Phone_No</td>
            <td><input type="number" name="Phone_no"></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><input type="text" name="Address"></td>
          </tr>
          <tr id ="city">
            <td>city</td>
            <td><input type="text" name="city"></td>
          </tr>
          <tr id ="zip">
            <td>Zip</td>
            <td><input type="text" name="zip_code"></td>
          </tr>
          <tr>
            <td style="width:300px;">Insurance Accepted</td>
              <td>
            <select name="Insurance_id[]" id="Insurance_id" multiple="multiple">
              <option value="0">Select Category</option>
              <?php $listing = mysql_query("select * from health_care_db.insurance");
                                    while($listing_fetch = mysql_fetch_object($listing))
                            
                {?>
              <option value="<?php echo $listing_fetch->Insurance_id;?>" > <?php echo $listing_fetch->Company_name;?></option>
              <?php 
                      
                } ?></select></td></tr>
                <tr id="bg">
                <td>
                
                
                
                
                Blood Group
                
                
                
                
                </td>
                <td>
                <select name="patient_BloodGroup" id="patient_BloodGroup">
              <option value="AB">AB+</option>
              <option value="A">A+</option>
              <option value="A">A-</option>
              <option value="B">B+</option>
              <option value="A">B-</option>
              <option value="B">O+</option>
              <option value="B">O-</option>
              <option value="B">RH factor</option>
            </select>
              </td>
          </tr>
          <tr id="DOB">
            <td>DOB</td>
            <td><input type="datepicker" id="datepicker" name="datepicker" size="20"></td>
          <tr id="doctors">
            <td style="width:300px;">Doctors</td>
            <td><?php $a = explode(',',$Patient_detail['Doctor_id']);?>
              <select name="arrdoctors[]" id="catname[]" >
                <option value="0">Select Doctors</option>
                <?php $listing1 = mysql_query("select * from health_care_db.doctors where Doctors_id ='".$_SESSION['Doctors_id']."'");
                       		while($listing_fetch1 = mysql_fetch_object($listing1)) {
				//$selected='';
				foreach($a as $key=>$val){
                                    if($val==$listing_fetch1->Doctors_id)
                                        {
                                        //$selected='selected';
                                    }
				}
					?>
                <option <?php echo $selected;?> value="<?php echo $listing_fetch1->Doctors_id;?>" ><?php echo $listing_fetch1->Doctors_name;?></option>
                <?php 
                        
                                        } ?>
              </select></td>
          </tr>
            </tr>
          
          
            <td><input id="button" type="submit" name="submit" value="Add Patient"></td>
          </tr>
        </table>
      </fieldset>
    </form>
  </div>
</div>
</body>
</html>