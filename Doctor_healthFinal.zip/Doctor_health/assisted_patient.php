<?php
include("config.php");

if($_SESSION['email'] !='')
{
	session_regenerate_id(true);
//header("Location:index.php");
}

error_reporting(0);
//
    //$rs_history_all= $rs_history_all1[0];
//var_dump($rs_history_all1);
    //die;
$rs_appointmented_patient = getAllRecordFromTableWithJoin('appointment',array('patient'=>'appointment.Patient_id=patient.Patient_id'),array('appointment.Doctors_id'=>$_SESSION['Doctors_id']),'appointment.*,patient.Patient_name');
$appointmented_patient = $rs_appointmented_patient[0];
//var_dump($rs_appointmented_patient);
//die;
$rs_assisted_patient = getAllRecordFromTableWithJoin('prescription',
                                              array('patient'=>'prescription.Patient_id=patient.Patient_id'),
                                              array('prescription.Doctors_id'=>$_SESSION['Doctors_id'],"prescription.prescription_Info<>''"),'prescription.*,patient.Patient_name');
$rs_assisted_patient_name = getAllRecordFromTableWithJoin
        ('prescription', array('patient'=>'prescription.Patient_id=patient.Patient_id'),
       array('prescription.Doctors_id'=>$_SESSION['Doctors_id'],"prescription.prescription_Info<>''"),
      'DISTINCT(`prescription`.`Patient_id`),patient.Patient_name');
$assisted_patient_list=query_fatchdata("SELECT patient.Patient_name, 
                        COUNT(*) as assisted  
                       FROM prescription,patient  
                       WHERE prescription.Patient_id=patient.Patient_id and  
                       prescription_Info<> '' and Doctors_id ='".$_SESSION['Doctors_id']."' 
                       GROUP BY prescription.Patient_id");
       // $row = mysql_fetch_row($query);
        
   //var_dump($assisted_patient_list);die;
  $assistedlatest_date=query_fatchdata("SELECT patient.Patient_name, prescription.Patient_id,  prescription_dts
  FROM prescription,patient WHERE prescription_dts IN (
    SELECT MAX( prescription_dts )
      FROM prescription WHERE prescription_Info<> '' and patient.Patient_id = prescription.Patient_id GROUP BY prescription.Patient_id
  )");
  
         //var_dump($assistedlatest_date);die; 
        

?>
<?php
     include_once ('Includes/header.php');
     ?>
<div id="prescription-column-middle"style="height:auto;" >
<div id="appointment-story-box" class="patient-background" style="height:auto;">
    <div id="title-box2" class="title-box-background-orange title-medium" ></div>
    
    
    <table style="width:100%" border="0">
      <thead>	
   <td>Sr No</td>   
    <td>Patient</td>
    <td>Times of assistance</td>
    <td>Latest Date</td>
    </thead>
  <tbody>
  <?php $i = 1;foreach($assistedlatest_date as $rs_assisted_patient_list){?>
  <tr>
      <td><?php echo $i;?></td>
      <td><?php echo $rs_assisted_patient_list['Patient_name'];?></td>
            <td><?php foreach($assisted_patient_list as $rs_assisted_patient_list_count){
                                  echo $rs_assisted_patient_list_count['assisted'];
                }?>
            </td>
            <td><?php echo $rs_assisted_patient_list['prescription_dts'];?></td>
    </tr>
     <?php $i++; } ?>
 
  </tbody>
</table>
</div>
    </div>
    </div>
</body>
</html>