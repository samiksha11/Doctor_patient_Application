<?php include("config.php"); 
if($_SESSION['username'] == '')
{
	header("Location:index.php");
}
$msg = "";
error_reporting(0);
extract($_POST);
if($_POST['submit'] && $_POST['submit'] == 'Submit')
{ 
	$old_password = md5($old_pass);
	$qry = mysql_query("select * from users where username = '".$_SESSION['username']."' AND password = '$old_password' AND role = 1 ");
	
	if(mysql_num_rows($qry) > 0)
	{
	   $new_password = md5($new_pass);
	   $sql_pass = mysql_query("update users set password='$new_password' where role = '1' And username = '".$_SESSION['username']."' ");
	   if($sql_pass)
	   {
		  $msg = "Password Changed Successfully"; 
	   }
	}
	else
	{
		$msg = "Old Password Not Match";
	}
}
?>

<script>
function validate_form()
{
	var err = "";
	if(document.form1.old_pass.value == "")
	{
		err = err + "Please Enter Old Password\n"; 
	}
	if(document.form1.new_pass.value == "")
	{
		err = err + "Please Enter New Password\n";
	}
	if(document.form1.re_pass.value == "")
	{
		err = err + "Please Enter Password in Retype Password Field\n";
	}
	if(document.form1.re_pass.value != document.form1.new_pass.value)
	{
		err = err + "Please Enter Same Password in Retype Password Field\n";
	}
	if(err != "")
	{
		alert(err);
		return false;
	}
	else
	{
		return true;
	}
}
</script>

<?php include_once('includes/header.php'); ?>

<div id="wrapper">
    <section class="container" role="main">
        <div class="row">
            <article class="span12 data-block">
                <header>
               		<h2><span class="icon-folder-open"></span>Change Password</h2>
                </header>
                <section class="no-padding">
					<?php if(isset($msg)){ echo "<p style='font-size:20px;margin-left:130px;color:#F00;'>".$msg."</p>"; } ?>
                    <form action="" method="post" name="form1" id="form1"  onsubmit="return validate_form();" class="header-search" 
                    style="float:left;color:#000;display: inline-block;font-size: 17.5px;">
                    <table class="table table-striped table-bordered table-condensed table-hover table-media no-margin">
                        <tbody>
                            <tr>
                                <td style="width:200px;">Old Password &nbsp;<span style="color:#F00;">*</span></td>
                                <td><input type="password" name="old_pass" id="old_pass" style="height:30px;"/></td>
                            </tr>
                            
                            <tr>
                                <td style="width:200px;">New Password &nbsp;<span style="color:#F00;">*</span></td>
                                <td><input type="password" name="new_pass" id="new_pass" style="height:30px;"/></td>
                            </tr>

                            <tr>
                                <td>Retype Password &nbsp;<span style="color:#F00;">*</span></td>
                                <td><input type="password" name="re_pass" id="re_pass" style="height:30px;"/></td>
                            </tr>

                            <tr>
                                <td>&nbsp;&nbsp;</td>
                                <td> <input type="submit" name="submit" value="Submit" class="btn btn-alt btn-large btn-primary" /></td>
                            </tr>
                        </tbody>
                    </table>
                    </form>   
                </section>
            </article>
        </div>
    </section>
    <div id="push"></div>
</div>
<?php include_once('includes/footer.php'); ?>
