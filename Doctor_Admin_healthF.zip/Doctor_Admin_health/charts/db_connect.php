<?php
error_reporting(0);
session_start();
if ($_SERVER['HTTP_HOST']=='localhost')
{
	$mysql_host = "localhost";
	$mysql_database = "health_care_db";
	$mysql_user = "root";
	$mysql_password = "";
	$siteUrl = "";
	$sitefolder = "";
	
}
else
{
	$mysql_host = "localhost";
	$mysql_database = "";
	$mysql_user = "";
	$mysql_password = "";
	$siteUrl = "";
	$sitefolder = "";
}
$sql_connect = mysql_connect($mysql_host,$mysql_user,$mysql_password);
$db = mysql_select_db($mysql_database,$sql_connect);

if(!$db)
{
  echo "database not connected";	
}

include_once("includes/sql_lib.php"); 
require("includes/customFunction.php");
 
?>