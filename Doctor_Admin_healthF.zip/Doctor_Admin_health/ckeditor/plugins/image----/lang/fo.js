﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'fo', {
	alertUrl: 'Rita slóðina til myndina',
	alt: 'Alternativur tekstur',
	border: 'Bordi',
	btnUpload: 'Send til ambætaran',
	button2Img: 'Skal valdi myndaknøttur gerast til vanliga mynd?',
	hSpace: 'Høgri breddi',
	img2Button: 'Skal valda mynd gerast til myndaknøtt?',
	infoTab: 'Myndaupplýsingar',
	linkTab: 'Tilknýti',
	lockRatio: 'Læs lutfallið',
	menu: 'Myndaeginleikar',
	resetSize: 'Upprunastødd',
	title: 'Myndaeginleikar',
	titleButton: 'Eginleikar fyri myndaknøtt',
	upload: 'Send',
	urlMissing: 'URL til mynd manglar.',
	vSpace: 'Vinstri breddi',
	validateBorder: 'Bordi má vera eitt heiltal.',
	validateHSpace: 'HSpace má vera eitt heiltal.',
	validateVSpace: 'VSpace má vera eitt heiltal.'
} );
