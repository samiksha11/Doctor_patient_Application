﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'sl', {
	alertUrl: 'Vnesite URL slike',
	alt: 'Nadomestno besedilo',
	border: 'Obroba',
	btnUpload: 'Pošlji na strežnik',
	button2Img: 'Želiš pretvoriti izbrani gumb s sliko v preprosto sliko?',
	hSpace: 'Vodoravni razmik',
	img2Button: 'Želiš pretvoriti izbrano sliko v gumb s sliko?',
	infoTab: 'Podatki o sliki',
	linkTab: 'Povezava',
	lockRatio: 'Zakleni razmerje',
	menu: 'Lastnosti slike',
	resetSize: 'Ponastavi velikost',
	title: 'Lastnosti slike',
	titleButton: 'Lastnosti gumba s sliko',
	upload: 'Pošlji',
	urlMissing: 'Manjka vir (URL) slike.',
	vSpace: 'Navpični razmik',
	validateBorder: 'Meja mora biti celo število.',
	validateHSpace: 'HSpace mora biti celo število.',
	validateVSpace: 'VSpace mora biti celo število.'
} );
